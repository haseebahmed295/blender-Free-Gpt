from .errors import RequestsError

RequestsException = RequestsError
